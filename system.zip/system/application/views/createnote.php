<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/postUplordPage.css')?>">
    <title>Document</title>
    <script src="<?php echo base_url('assets/js/textEditor/ckeditor.js')?>"></script>
</head>
<body>
    <?php if(!$this->session->userdata('loggedIn')){
          redirect('welcome/lohinPage');
    }?>
    <div class="nav-bar">
        <a href="<?php echo base_url('index.php/welcome/logout');?>">logOut</a>

        <?php   echo "<h3>"; 
                    echo 'HELLO '.$this->session->userdata('fname');
                echo "<h3>";
        ?>  
    </div>
       <div class="form">
       <h2>Create Post</h2>
            <?php echo form_open_multipart('welcome/uplordnote');?>  
                <input name="uid" type="hidden" value="<?php echo $_SESSION['uid']?>">
                <label for="title">Titel</label><br>
                <?php echo form_input(['name'=>'notetopic','placeholder'=>'Add title','type'=>'textbox','id'=>'topic']);?><br>
                <label for="title">Body</label><br>
                <textarea name="note" id="editor1"></textarea><br>
                <?php echo form_submit(['name'=>'submit','value'=>'POST','type'=>'submit','id'=>'post']);?><br>  
            <?php echo form_close();?>
       </div>
       <script src=".<?php echo base_url('assets/js/textEditor/ckeditor.js')?>."></script>
       <script>
                CKEDITOR.replace( 'editor1' );
        </script>
</body>
</html>