<?php
   if(!$this->session->userdata('loggedIn')){
        redirect('welcome/loginpage');
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/log.css')?>">
    <title>Document</title>
</head>
<body>
          
        <div class="navigations clearfix" id="navigations">
            <ul>
                <li><a href="<?php echo base_url('index.php/welcome/logout');?> ">logOut</a></li>
                <li><a href="<?php echo base_url('index.php/welcome/createnote');?>">Add Note</a></li>    
            </ul>
        </div>
      
   
    <div class="main_body clearfix">
    <?php
        $uid=$_SESSION['uid'];
        $query=$this->db->query("SELECT * FROM note WHERE uid=$uid");
        if($query->num_rows()>0){
        foreach($query->result() as $row){
                echo "
                <div class='note clearfix'>
                        <div class='post_heding clearfix'>
                            <h1>".strtoupper($row->notetopic)."</h1>
                        </div>
                        <div class='post_body clearfix'>
                            ".$row->note."
                        </div>
                        <div class='actions clearfix'>
                            <a href=".base_url('index.php/welcome/viewCount?postid='.$row->Nid)." id='readmore'>Delete</a>
                        </div>
                </div>  
                    ";
            }
        }else{

       }
    ?>
    </div>

    

</body>
</html>